package expressions;

public class FormalProof extends Proof{
    public static final String DED = "Ded. %d";
    public static final String HYP = "Hyp. %d";
    public static final String AX = "Ax. sch. %d";
    public static final String MP = "M.P. %d, %d";
    public static final String INC = "Incorrect";
    public static final String FROM_INC = "; from Incorrect";

    private final int n;
    public boolean fromIncorrect;
    public boolean incorrect;
    private String conclusion;

    public FormalProof(Context lhs, LogicExpression rhs, int n) {
        super(lhs, rhs);
        this.n = n;
    }

    public FormalProof(Proof proof, int n) {
        this(proof.getContext(), proof.getExpression(), n);
    }

    public void setConclusion(String conclusion) {
        this.conclusion = conclusion;
    }

    @Override
    public String getProof() {
        return "[" + n + "] " + super.getProof() + " [" + conclusion + (fromIncorrect ? FROM_INC : "") + "]";
    }
}
