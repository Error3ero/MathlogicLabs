package axioms;

import expressions.LogicExpression;

public interface AxiomSchema {
    boolean equalsAxiom(LogicExpression expression);
}
